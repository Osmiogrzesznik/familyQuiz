<?php
include 'DBtools.php';
/*
if person sent mylastId and it is smaller than curr question id ?
if person requests next question it only should be granted when previous question has been answered 
answered status is set in separate file
*/

//getnextquestion link moze byc zcustomizowany
//qjesli bedzie sie odnosiÅ‚ do wewnetrzego pliku
//zobacz czy da sie file_get_contents gdy adresatem jest inny skrypt PHP na tym samym serwerze, ktory echo-uje np. cos w formacie JSON
// !!!!!! Gra Customowa w ktorej prowadzacy zadaje pytania z wlasnej bazy danych!!!!!
/// moze dawac linki do Youtube(zobacz czy jest mozliwe embedowanie krotkich fragmentow) albo do obrazkow
$rqst=json_decode(file_get_contents("php://input"),true);

$iscustomGame = (isset($rqst['isCustom'])) ? $rqst['isCustom'] : FALSE ;
$clientLastId = (isset($rqst['myLastId'])) ? $rqst['myLastId'] : 0 ;
$amount='amount=1';
$category='category='.(isset($rqst['category'])) ? $rqst['MyLastId'] : 0 ;


$GETNEXTQUESTIONLINK = 'https:/'.'/opentdb.com/api.php?'.$amount.$category;


$dbcon=new sqlite3ext('QuizDB.sqlite'); //or die("unable to open database");
$isthereaTable=$dbcon->table_exists("questions_list");

if (!$isthereaTable){//no table
$createTable= <<<EOD
CREATE TABLE IF NOT EXISTS 'questions_list'
(Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
question TEXT UNIQUE NOT NULL,
isAnswered INTEGER NOT NULL DEFAULT 0);
INSERT INTO questions_list(question, isAnswered)
VALUES ('thefirstQuestion',1);
EOD;
$dbcon->query($createTable);
//echo "<br>createdTable<br>";
}

$lastr = "SELECT * FROM questions_list ORDER BY Id DESC LIMIT 1";
$isAnsw=boolval($dbcon->query($lastr)->fetchArray()['isAnswered']);

//echo "<br>is Answered:?<br>";
//var_dump($isAnsw);
if ($isAnsw){
$qs=file_get_contents($GETNEXTQUESTIONLINK);
$qs=json_encode(json_decode($qs)->results[0]);
$addQuestionQry = <<<EOD
INSERT INTO questions_list(question,isAnswered)
VALUES('$qs',0);
EOD;
$result=$dbcon->exec($addQuestionQry);
//echo "<br>inserting new question<br>";
//var_dump($result);
WriteAppendJSONishFile($qs);
}

/*$getevthng= <<<EOD
SELECT * FROM questions_list
EOD;
$result=sqlite_fetch_all($dbcon->query($getevthng));*/
//$dbcon->query($getevthng)->fetchAll();

//echo $result;
//var_dump($result);

/*

EOD;
$insertNewqs= <<<EOD
INSERT INTO questions_list(question)
SELECT '$qs'

$dbcon->query($createTable)*/

?>