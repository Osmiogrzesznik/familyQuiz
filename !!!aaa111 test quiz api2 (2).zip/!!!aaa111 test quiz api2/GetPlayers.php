<?php

include 'DBtools.php';
$dbcon=new SQLite3ext("QuizDB.sqlite") or die("unable to open database");
$JSONDefaultResponse = array(
    "isEverythingOK" => NULL,
    "msg"=>NULL,
    "profiles"=>array(),
    );
$rsp=$JSONDefaultResponse;

if (!isset($_POST['RoomId'])){
$rsp['isEverythingOK']=FALSE;
$rsp['msg'].="\nNo Room Id";
echo json_encode($rsp);
exit;
}

$Room = "room_".$_POST['RoomId'];
if (!$dbcon->Table_Exists($Room)){
$rsp['isEverythingOK']=FALSE;
$rsp['msg'].="\nNo Such Room with ID:". $_POST['RoomId'];
echo json_encode($rsp);
exit;
}
$players=$dbcon->fetch_all("SELECT * FROM $Room");
//$players["3"]['Points']="555555";

$rsp = json_encode($players);

echo $rsp;


?>
