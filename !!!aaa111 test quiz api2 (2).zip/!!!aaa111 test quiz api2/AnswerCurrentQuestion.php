<?php
include 'DBtools.php';
if (!isset($_COOKIE['RoomMemberId'])){
    echo "Please Login First";
    exit;
}


$GETANSWERLINK='php://input';
//there should be separate website-displayer serving as tv-presentation 
//and separate controller website for MASTER allowing to control category questions and layout on the master
$rqst=json_decode(file_get_contents($GETANSWERLINK),TRUE);
$ans=$rqst['answer'];
$isAnsCorrectClientSide=$rqst['isCorrect'];
$RoomMemberId=$_COOKIE['RoomMemberId'];



$dbcon=new sqlite3('QuizDB.sqlite'); //or die("unable to open database");
$isTableQry= <<<EOD
SELECT name FROM sqlite_master WHERE type='table' AND name='current_question_answers'
EOD;
$isTableRs=$dbcon->query($isTableQry);
$isTable=$isTableRs->fetchArray();
//var_dump($result);
//echo"<br>";

if (!$isTable){//no table
$createTable= <<<EOD
CREATE TABLE IF NOT EXISTS 'current_question_answers'
(Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
answer TEXT NOT NULL,
RoomMemberId INTEGER UNIQUE NOT NULL,
isCorrect INTEGER NOT NULL DEFAULT 0);
INSERT INTO current_question_answers(answer, isCorrect)
VALUES ('thefirstQuestion',1);
EOD;
$dbcon->query($createTable);
//echo "<br>createdTable<br>";
}

$lastr = "SELECT * FROM current_question_answers ORDER BY Id DESC LIMIT 1";
$isLastCorrect=boolval($dbcon->query($lastr)->fetchArray()['isCorrect']);

//echo "<br>is Answered:?<br>";
//var_dump($isAnsw);
if (!$isLastCorrect){//it means we are still waiting

$addAnswerQry = <<<EOD
INSERT INTO current_question_answers(answer,isCorrect)
VALUES('$ans',0);
EOD;
$result=$dbcon->exec($addAnswerQry);
//echo "<br>inserting new question<br>";
//var_dump($result);
//WriteAppendJSONishFile($qs);
}
else{
    
}

/*$getevthng= <<<EOD
SELECT * FROM current_question_answers
EOD;
$result=sqlite_fetch_all($dbcon->query($getevthng));*/
//$dbcon->query($getevthng)->fetchAll();

//echo $result;
//var_dump($result);

/*

EOD;
$insertNewqs= <<<EOD
INSERT INTO current_question_answers(question)
SELECT '$qs'

$dbcon->query($createTable)*/

?>





?>