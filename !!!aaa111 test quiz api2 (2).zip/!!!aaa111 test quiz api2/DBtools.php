<?php








function WriteAppendJSONishFile($msg) {
$today = date("Y_m_d"); 
$logfile = $today."_log.txt"; 
$dir = 'QuestionsStorageFolder';
$saveLocation=$dir . '/' . $logfile;
if (!$handle = @fopen($saveLocation, "a")) {
return;
}
else {
if (@fwrite($handle,"$msg\r\n,") === FALSE) {
return;
}
 
@fclose($handle);
}
}

function show_var($varry){
echo "<pre>";
 var_dump($varry);
 echo "</pre>";
}

class sqlite3ext extends SQLite3{
		function row_exists_id($tablename,$columnName,$value){
			$Qry= 
<<<EOD
    SELECT Id FROM $tablename WHERE $columnName = '$value';
EOD;
      $Id=$this->query($Qry);
			return $Id->f;
		}
	
    function table_exists($tablename){
         $isTableQry=
<<<EOD
    SELECT name FROM sqlite_master WHERE type='table' AND name='$tablename' 
EOD;
        $isTableRs=$this->query($isTableQry);
        return boolval($isTableRs->fetchArray());
    }
    /** 
 * returns an associative array of given querystring
 *
 * @param string $querystring query to perform
 */
    
    function fetch_all($querystring){
        $queryResultSet = $this->query($querystring);
        $multiArray = array();
        $count = 0;
        while($row = $queryResultSet->fetchArray(SQLITE3_ASSOC)){
        foreach($row as $i=>$value) {
        $multiArray[$count][$i] = $value;
        }
        $count++;
        }
        return $multiArray;
}
/** 
 * Dumps contents of table inside the db connected to
 *
 * performs var_dump on fetch_all, namely outputs all contents into HTML
 *
 * @param string $tablename name of the table
 */
function dump_table($tablename){
        
        if (TRUE){//$this->table_exists($tablename)){
        echo "<pre>";
        echo "Dumping contents of $tablename as PHP Array";
        var_dump($this->fetch_all("SELECT * FROM $tablename"));
        echo "</pre>";
        }
        else {
            echo "no such table $tablename";
        }

    }
}














?>