<?php
include 'DBtools.php';
$source = "php://input";
//$source = "testjsonrequest.json";
$rqstJSON=file_get_contents($source);
$dbcon=new SQLite3ext("QuizDB.sqlite") or die("unable to open database");
$defaultimgPath="images/avatars/nobody.jpg";
$JSONDefaultResponse = array(
    "isEverythingOK" => NULL,
    "msg"=>NULL,
    "profile"=>array(),
    );




function update_picture($RoomMemberId,$Room,$folderName){
    global $dbcon;
    $info = pathinfo($_FILES['avatar']['name']);
        $ext = $info['extension']; // get the extension of the file
        $newname = $RoomMemberId.".".$ext; 
        $targetpath = 'images/'.$folderName."/".$newname;

        move_uploaded_file( $_FILES['avatar']['tmp_name'], $targetpath);
        
       
        $UpdatePictureQry= <<<EOD
UPDATE $Room
SET ImagePath = '$targetpath'
WHERE Id = $RoomMemberId;
EOD;
        $ok=$dbcon->exec($UpdatePictureQry);
 return array("ok"=>$ok,"picturePath"=>$targetpath); 
}


//var_export($_FILES);
//var_export($_POST);



if((!isset($rqstJSON) or !$rqstJSON) and !isset($_POST['Name'])){
$rsp=$JSONDefaultResponse;
$rsp['isEverythingOK']=FALSE;
$rsp['msg'].="\nDidn't send us any POST OR JSON";
echo json_encode($rsp);
exit;
}

if (!isset($_POST['Name'])){
$rqs=json_decode($rqstJSON,TRUE);
}
else{
    $rqs=$_POST;
 
	
}

if (!$rqs){
$rsp=$JSONDefaultResponse;

$rsp['isEverythingOK']=FALSE;
$rsp['msg'].="\nsomething went really wrong we could not parse your JSON or POST was shitty . Your Post:". var_export($rqs['Name'],TRUE);
echo json_encode($rsp);
exit;
}

//Logged In 
$rsp=$JSONDefaultResponse;
//
//if (isset($_COOKIE['RoomMemberId'])){
//    $rsp['isEverythingOK']=FALSE; 
//    $rsp['msg'].= "\n Please STOP requesting ADDMETOROOM .You Are Already Logged In As member with ID".$_COOKIE['RoomMemberId']." in Room with ID".$_COOKIE['RoomId'];
//		echo json_encode($rsp);
//		exit;
//		}

if (!isset($rqs['RoomIdIWant'])){
		$rsp['isEverythingOK']=FALSE;
                $rsp['msg'].="\n no room chosen";
		echo json_encode($rsp);
		exit;
		}
  

$Room = "room_".$rqs['RoomIdIWant'];

if (!$dbcon->Table_Exists($Room)){
	$createTable= <<<EOD
CREATE TABLE IF NOT EXISTS '$Room'
(Id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
Name TEXT UNIQUE NOT NULL,
Points INTEGER NOT NULL DEFAULT 0,
ImagePath TEXT NOT NULL DEFAULT '$defaultimgPath');
EOD;
$dbcon->query($createTable);
//echo "<br>createdTable<br>";
}

$Name=$rqs['Name'];
$NameESC=$dbcon->escapeString($rqs['Name']);
$newAvatarUploaded=boolval($_FILES['avatar']['name']);



$existingMember=$dbcon->querySingle("SELECT * FROM $Room WHERE Name='$NameESC';", TRUE);
    
//$gotId=$dbcon->row_exists_id($Room,'Name',$Name);
//show_var($existingMember);

if (boolval($existingMember)){
    $rsp['msg'].="\nWe found Your Name in Database and logging you in as that(you) person";
    if ($newAvatarUploaded){
           $updatedPictureResp=update_picture($existingMember['Id'],$Room,"avatars");
        If(!$updatedPictureResp["ok"]){
        $rsp['isEverythingOK']=FALSE;
        $rsp['msg'].="\nFailure replacing your picture path in Database";
        exit;
        }
         $existingMember['ImagePath'] = $updatedPictureResp['picturePath'];
    }
   
      $profile=$existingMember;
      
}
else{ 

    $AddMember= <<<EOD
INSERT INTO '$Room'(Name)
VALUES('$NameESC');
EOD;
    If(!$dbcon->exec($AddMember)){
        $rsp['isEverythingOK']=FALSE;
        $rsp['msg'].="\nFailure, even though we were checking in code , something went wrong while adding your name to Database";
        exit;
    };
    $RoomMemberId=$dbcon->lastInsertRowid();
       if ($newAvatarUploaded){
           $updatedPictureResp=update_picture($RoomMemberId,$Room,"avatars");
        If(!$updatedPictureResp["ok"]){
        $rsp['isEverythingOK']=FALSE;
        $rsp['msg'].="\nFailure, even though we were checking in code , something went wrong while adding your picture path to Database";
        exit;
        };
        $picturepath=$updatedPictureResp['picturePath'];
    }
    else{
        $picturepath=$defaultimgPath;
    }
    $profile=array(
        'Id' => $RoomMemberId,
        'Name' => $Name,
        'Points' => 0,
        'ImagePath' => $picturepath
        );
}




$rsp['profile']=$profile;
$rsp['isEverythingOK']=TRUE;
$rsp['msg'].="\nSuccess, You joined The Room , now Add a picture";



if (isset($rqs['sendFromHTML']) && $rqs['sendFromHTML']){
    setcookie("RoomMemberId",$rsp['profile']['Id']);
    setcookie("RoomId",$rqs['RoomIdIWant']);
}


echo json_encode($rsp);


?>