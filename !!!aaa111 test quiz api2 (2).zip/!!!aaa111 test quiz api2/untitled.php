<?php
include 'DBtools.php';
$dbcon= new Sqlite3ext("QuizDB.sqlite");

$query= <<<EOD
DROP TABLE room_1
EOD;
$dbcon->query($query);

$dbcon->dump_table("sqlite_master");
//$tblname="";
?>