<?php
//setcookie("RoomMemberId","546");
   include 'DBtools.php';/*
  $dbcon = new sqlite3ext("QuizDB.sqlite") ;
 $dbcon->dump_table("questions_list")*/
//echo file_get_contents("php://input");
//echo "dupa";
echo json_encode($_POST)

?>